#!/usr/bin/env python3
"""Reproducible localhost smoke benchmark, using its own temporary database."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import http.client
import json
import math
from pathlib import Path
import platform
import socket
import subprocess
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', default='build/mini-redis')
    parser.add_argument('--requests', type=int, default=500, help='requests per workload')
    parser.add_argument('--clients', type=int, default=8)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--output', help='optional JSON report path')
    args = parser.parse_args()
    if not 1 <= args.requests <= 1000000 or not 1 <= args.clients <= 128 or not 1 <= args.workers <= 64:
        parser.error('requests: 1–1000000, clients: 1–128, workers: 1–64')
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]

    def request(method, key, value=None):
        conn = http.client.HTTPConnection('127.0.0.1', port, timeout=15)
        try:
            conn.request(method, '/keys/' + key, body=json.dumps({'value': value}) if value is not None else None, headers={'Content-Type': 'application/json'})
            response = conn.getresponse()
            response.read()
            if response.status not in (200, 201):
                raise RuntimeError('HTTP ' + str(response.status))
        finally:
            conn.close()

    binary = str(Path(args.binary).resolve())
    with tempfile.TemporaryDirectory(prefix='mini-redis-bench-') as tmp:
        log = tempfile.TemporaryFile(mode='w+')
        proc = subprocess.Popen([binary, '--port', str(port), '--threads', str(args.workers), '--data-dir', tmp], stdout=log, stderr=log)
        try:
            for _ in range(200):
                if proc.poll() is not None:
                    log.seek(0)
                    raise RuntimeError(log.read())
                try:
                    request('PUT', 'warmup', 'x')
                    break
                except OSError:
                    time.sleep(.025)
            else:
                raise RuntimeError('server failed to start')
            value = 'x' * 256
            for i in range(100):
                request('PUT', 'bench:' + str(i), value)
            results = []
            for name in ('read', 'write', 'mixed_80_percent_read'):
                def operation(i):
                    begin = time.perf_counter()
                    write = name == 'write' or (name.startswith('mixed') and i % 5 == 0)
                    request('PUT' if write else 'GET', 'bench:' + str(i % 100), value if write else None)
                    return (time.perf_counter() - begin) * 1000
                begin = time.perf_counter()
                with ThreadPoolExecutor(max_workers=args.clients) as pool:
                    latencies = sorted(pool.map(operation, range(args.requests)))
                elapsed = time.perf_counter() - begin
                def percentile(p):
                    return round(latencies[max(0, math.ceil(p * len(latencies)) - 1)], 3)
                result = {'workload': name, 'requests': args.requests, 'elapsed_seconds': round(elapsed, 3), 'requests_per_second': round(args.requests / elapsed, 1), 'p50_ms': percentile(.5), 'p95_ms': percentile(.95), 'p99_ms': percentile(.99)}
                results.append(result)
                print(f"{name:26} {result['requests_per_second']:>8} req/s | p50 {result['p50_ms']:>7} ms | p95 {result['p95_ms']:>7} ms | p99 {result['p99_ms']:>7} ms")
            report = {'platform': platform.platform(), 'architecture': platform.machine(), 'python': platform.python_version(), 'clients': args.clients, 'server_workers': args.workers, 'value_bytes': 256, 'keys': 100, 'durability': 'fsync every write', 'connection_reuse': False, 'results': results, 'note': 'Local smoke benchmark, not a Redis comparison. Includes Python client overhead, TCP setup, and HTTP/JSON encoding. Short runs are noisy.'}
            if args.output:
                Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
        finally:
            if proc.poll() is None:
                proc.terminate()
            proc.wait(timeout=12)
            log.close()


if __name__ == '__main__':
    main()
