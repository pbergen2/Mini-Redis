# Validation record

Validated on September 30, 2026 on macOS, Apple Silicon, using Apple Clang 16.0.0 and Python 3.9.6.

| Check | Result |
| --- | --- |
| Release build with `-Wall -Wextra -Wpedantic` | Passed; no compiler warnings |
| `make test` | All 13 integration tests passed |
| `make sanitize SANITIZERS=undefined` | All 13 tests passed with UndefinedBehaviorSanitizer; recovery from sanitizer errors disabled |
| AddressSanitizer | Not completed: installed runtime crashes before application startup |
| Dashboard in a browser | Connected, created a demo key, cleared editor, loaded saved key; layout visually checked |
| Isolated benchmark | Completed all three workloads; raw report in `benchmark-results.json` |

The AddressSanitizer failure was reproduced with an independent `int main() { return 0; }` program. The runtime reported `sanitizer_malloc_mac.inc:189` during initialization. This does not establish that the application is free of memory errors; run the default `make sanitize` on a compatible compiler/runtime.

The integration tests cover successful and invalid REST requests, concurrent clients, abrupt process termination, replay, expiration across downtime, truncated log tails, corruption rejection, data-directory locking, pagination, local-origin restrictions, size limits, Unicode, and graceful restart. They do not simulate hardware power loss or disk-full failures. Linux and the optional CMake build were not exercised in this environment.

## Local smoke benchmark

Settings: 8 Python clients, 4 server workers, 100 keys, 256-byte values, 500 requests per workload, a new TCP connection for every request, `fsync` on each write. Each workload ran for less than one second; treat the results as a smoke check, not a stable performance claim.

| Workload | Requests/second | p50 latency | p95 latency | p99 latency |
| --- | ---: | ---: | ---: | ---: |
| Read | 7,529.6 | 0.952 ms | 1.743 ms | 3.063 ms |
| Write | 7,703.5 | 0.944 ms | 1.554 ms | 2.578 ms |
| 80% read / 20% write | 8,883.4 | 0.835 ms | 1.393 ms | 2.513 ms |

These include Python/client, TCP, and HTTP overhead. Short-run variation explains why the write workload can appear faster than reads. Do not compare these figures directly with Redis benchmark results. For a portfolio performance claim, run longer trials and report their methodology and variability.

The live demonstration was started with a separate preview data directory. The packaged project starts with its own `data/` directory when you run `./run.sh`; the example key is not bundled as application data.
