#include "store.hpp"
#include "json.hpp"
#include <algorithm>
#include <cerrno>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>

namespace {
constexpr char MAGIC[] = "MRAOF001";
constexpr uint32_t MAX_RECORD = 17 + MAX_KEY + MAX_VALUE;
std::runtime_error io_error(const std::string& what) { return std::runtime_error(what + ": " + std::strerror(errno)); }
void u32(std::string& out, uint32_t n) { for (int i = 0; i < 4; ++i) out += static_cast<char>((n >> (8 * i)) & 255); }
void u64(std::string& out, uint64_t n) { for (int i = 0; i < 8; ++i) out += static_cast<char>((n >> (8 * i)) & 255); }
uint32_t read32(const char* s) { uint32_t n = 0; for (int i = 0; i < 4; ++i) n |= uint32_t(static_cast<unsigned char>(s[i])) << (8 * i); return n; }
uint64_t read64(const char* s) { uint64_t n = 0; for (int i = 0; i < 8; ++i) n |= uint64_t(static_cast<unsigned char>(s[i])) << (8 * i); return n; }
uint32_t crc32(const std::string& s) {
    uint32_t crc = 0xffffffff;
    for (unsigned char c : s) {
        crc ^= c;
        for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}
void write_all(int fd, const std::string& bytes) {
    size_t p = 0;
    while (p < bytes.size()) {
        ssize_t n = ::write(fd, bytes.data() + p, bytes.size() - p);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) throw io_error("write log");
        p += static_cast<size_t>(n);
    }
}
std::string read_at(int fd, off_t offset, size_t length) {
    std::string result(length, '\0'); size_t p = 0;
    while (p < length) {
        ssize_t n = ::pread(fd, result.data() + p, length - p, offset + static_cast<off_t>(p));
        if (n < 0 && errno == EINTR) continue;
        if (n < 0) throw io_error("read log");
        if (!n) throw std::runtime_error("log changed during recovery");
        p += static_cast<size_t>(n);
    }
    return result;
}
}

int64_t Store::now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

Store::Store(const std::string& directory) {
    try {
        std::filesystem::create_directories(directory);
        auto path = std::filesystem::path(directory) / "appendonly.aof";
        fd_ = ::open(path.c_str(), O_RDWR | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
        if (fd_ < 0) throw io_error("open log");
        if (::flock(fd_, LOCK_EX | LOCK_NB) < 0) throw std::runtime_error("data directory is already in use (could not lock appendonly.aof)");
        recover();
        // Persist the directory entry for a newly created log as well.
        int dirfd = ::open(directory.c_str(), O_RDONLY | O_CLOEXEC);
        if (dirfd < 0) throw io_error("open data directory");
        int result = ::fsync(dirfd); int saved = errno; ::close(dirfd); errno = saved;
        if (result < 0) throw io_error("sync data directory");
        reaper_ = std::thread([this] {
            std::unique_lock<std::mutex> lock(mutex_);
            while (!stopping_) {
                wake_.wait_for(lock, std::chrono::milliseconds(250), [this] { return stopping_; });
                if (!stopping_) expire_locked(now_ms());
            }
        });
    } catch (...) { if (fd_ >= 0) ::close(fd_); throw; }
}

Store::~Store() {
    { std::lock_guard<std::mutex> lock(mutex_); stopping_ = true; }
    wake_.notify_all();
    if (reaper_.joinable()) reaper_.join();
    if (fd_ >= 0) ::close(fd_);
}

void Store::erase_memory(const std::string& key) {
    auto it = data_.find(key);
    if (it == data_.end()) return;
    stats_.value_bytes -= it->second.value.size();
    if (it->second.expiry) expiries_.erase(*it->second.expiry);
    data_.erase(it);
}
void Store::set_memory(const Item& item) {
    erase_memory(item.key);
    Entry e{item.value, item.expires_at_ms, std::nullopt};
    if (item.expires_at_ms) e.expiry = expiries_.emplace(item.expires_at_ms, item.key);
    data_.emplace(item.key, std::move(e));
    stats_.value_bytes += item.value.size();
}
void Store::expire_locked(int64_t now) {
    while (!expiries_.empty() && expiries_.begin()->first <= now) {
        std::string key = expiries_.begin()->second;
        erase_memory(key); ++stats_.expirations;
    }
}

void Store::recover() {
    struct stat st{};
    if (::fstat(fd_, &st) < 0) throw io_error("stat log");
    if (st.st_size == 0) {
        write_all(fd_, std::string(MAGIC, 8));
        if (::fsync(fd_) < 0) throw io_error("sync log header");
        stats_.log_bytes = 8; return;
    }
    if (st.st_size < 8 || read_at(fd_, 0, 8) != std::string(MAGIC, 8))
        throw std::runtime_error("invalid log header; refusing to overwrite data");
    off_t offset = 8;
    while (offset < st.st_size) {
        if (st.st_size - offset < 8) break;
        auto header = read_at(fd_, offset, 8);
        uint32_t length = read32(header.data()), expected_crc = read32(header.data() + 4);
        if (length < 17 || length > MAX_RECORD) throw std::runtime_error("invalid log record length at byte " + std::to_string(offset));
        if (st.st_size - offset - 8 < length) break;
        auto payload = read_at(fd_, offset + 8, length);
        if (crc32(payload) != expected_crc) throw std::runtime_error("log checksum mismatch at byte " + std::to_string(offset));
        char op = payload[0];
        uint64_t deadline = read64(payload.data() + 1);
        uint32_t kl = read32(payload.data() + 9), vl = read32(payload.data() + 13);
        if ((op != 'S' && op != 'D') || kl == 0 || kl > MAX_KEY || vl > MAX_VALUE || uint64_t(17) + kl + vl != length || deadline > INT64_MAX || (op == 'D' && (vl || deadline)))
            throw std::runtime_error("invalid log record at byte " + std::to_string(offset));
        Item item{payload.substr(17, kl), payload.substr(17 + kl, vl), static_cast<int64_t>(deadline)};
        if (!json::valid_utf8(item.key) || !json::valid_utf8(item.value)) throw std::runtime_error("invalid UTF-8 in log");
        if (op == 'S') set_memory(item); else erase_memory(item.key);
        offset += 8 + length;
    }
    if (offset != st.st_size) {
        std::cerr << "Recovery: removed incomplete final record (" << st.st_size - offset << " bytes)\n";
        if (::ftruncate(fd_, offset) < 0 || ::fsync(fd_) < 0) throw io_error("repair incomplete log tail");
    }
    stats_.log_bytes = offset;
    expire_locked(now_ms());
    stats_.expirations = 0; // Operational counters describe this process only.
}

void Store::append(char op, const Item& item) {
    if (!writable_) throw std::runtime_error("storage is read-only after a disk error; restart after fixing the disk");
    std::string payload(1, op);
    u64(payload, static_cast<uint64_t>(item.expires_at_ms));
    u32(payload, static_cast<uint32_t>(item.key.size())); u32(payload, static_cast<uint32_t>(item.value.size()));
    payload += item.key; payload += item.value;
    std::string record; u32(record, static_cast<uint32_t>(payload.size())); u32(record, crc32(payload)); record += payload;
    try {
        write_all(fd_, record);
        if (::fsync(fd_) < 0) throw io_error("sync log");
        stats_.log_bytes += static_cast<int64_t>(record.size());
    } catch (...) {
        // No further mutations after an uncertain disk error. Best-effort rollback.
        writable_ = false;
        if (::ftruncate(fd_, stats_.log_bytes) == 0) ::fsync(fd_);
        throw;
    }
}

std::optional<Item> Store::get(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex_); expire_locked(now_ms());
    auto it = data_.find(key);
    if (it == data_.end()) { ++stats_.misses; return std::nullopt; }
    ++stats_.hits; return Item{key, it->second.value, it->second.expires_at_ms};
}
bool Store::put(const std::string& key, const std::string& value, int64_t ttl_seconds) {
    if (key.empty() || key.size() > MAX_KEY || value.size() > MAX_VALUE || ttl_seconds < 0 || ttl_seconds > MAX_TTL)
        throw std::invalid_argument("invalid key, value, or TTL");
    std::lock_guard<std::mutex> lock(mutex_); auto now = now_ms(); expire_locked(now);
    bool created = data_.find(key) == data_.end();
    Item item{key, value, ttl_seconds ? now + ttl_seconds * 1000 : 0};
    append('S', item); // A success response is only possible after fsync.
    set_memory(item); ++stats_.writes; return created;
}
bool Store::remove(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex_); expire_locked(now_ms());
    if (data_.find(key) == data_.end()) return false;
    append('D', Item{key, "", 0}); erase_memory(key); ++stats_.deletes; return true;
}
std::vector<Item> Store::list(const std::string& prefix, const std::string& after, size_t limit, bool& more) {
    std::lock_guard<std::mutex> lock(mutex_); expire_locked(now_ms());
    std::vector<std::string> keys;
    for (const auto& pair : data_) {
        if (pair.first > after && pair.first.compare(0, prefix.size(), prefix) == 0) keys.push_back(pair.first);
    }
    std::sort(keys.begin(), keys.end()); more = keys.size() > limit;
    if (keys.size() > limit) keys.resize(limit);
    std::vector<Item> result;
    for (const auto& key : keys) result.push_back({key, "", data_.at(key).expires_at_ms});
    return result;
}
Stats Store::stats() {
    std::lock_guard<std::mutex> lock(mutex_); expire_locked(now_ms());
    Stats result = stats_; result.keys = data_.size(); result.writable = writable_; return result;
}
