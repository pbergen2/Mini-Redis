#include "http.hpp"
#include "dashboard.hpp"
#include "json.hpp"
#include <algorithm>
#include <arpa/inet.h>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <fcntl.h>
#include <iostream>
#include <map>
#include <netinet/in.h>
#include <poll.h>
#include <sstream>
#include <stdexcept>
#include <sys/socket.h>
#include <unistd.h>

volatile std::sig_atomic_t stop_requested = 0;
namespace {
constexpr size_t MAX_HEADERS = 16384, MAX_BODY = 524288, MAX_QUEUE = 128;
struct HttpError : std::runtime_error {
    int status;
    HttpError(int code, const std::string& message) : std::runtime_error(message), status(code) {}
};
struct Request { std::string method, target, body; std::map<std::string, std::string> headers; };
struct Response { int status; std::string body; std::string type = "application/json; charset=utf-8"; };
std::string lower(std::string s) { for (char& c : s) if (c >= 'A' && c <= 'Z') c += 'a' - 'A'; return s; }
std::string trim(std::string s) {
    auto begin = s.find_first_not_of(" \t"), end = s.find_last_not_of(" \t");
    return begin == std::string::npos ? "" : s.substr(begin, end - begin + 1);
}
uint64_t decimal(const std::string& s, uint64_t max) {
    if (s.empty()) throw HttpError(400, "expected a nonnegative integer");
    uint64_t n = 0;
    for (char c : s) {
        if (c < '0' || c > '9' || n > max / 10 || (n == max / 10 && uint64_t(c - '0') > max % 10))
            throw HttpError(400, "integer is invalid or too large");
        n = n * 10 + c - '0';
    }
    return n;
}
std::string decode(const std::string& s, bool query = false) {
    std::string out;
    auto hex = [](char c) -> int { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; };
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%') {
            if (i + 2 >= s.size() || hex(s[i + 1]) < 0 || hex(s[i + 2]) < 0) throw HttpError(400, "invalid percent encoding");
            out += static_cast<char>(hex(s[i + 1]) * 16 + hex(s[i + 2])); i += 2;
        } else out += (query && s[i] == '+') ? ' ' : s[i];
    }
    if (!json::valid_utf8(out)) throw HttpError(400, "URL must decode to UTF-8");
    return out;
}
Request read_request(int fd) {
    std::string buffer; char chunk[8192];
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    auto receive = [&] {
        for (;;) {
            auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
            if (remaining <= 0) throw HttpError(408, "request timed out");
            pollfd pfd{fd, POLLIN, 0};
            int ready = ::poll(&pfd, 1, static_cast<int>(remaining));
            if (ready < 0 && errno == EINTR) continue;
            if (ready < 0) throw HttpError(400, "socket read failed");
            if (!ready) throw HttpError(408, "request timed out");
            ssize_t n = ::recv(fd, chunk, sizeof(chunk), 0);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) throw HttpError(400, "incomplete request");
            buffer.append(chunk, static_cast<size_t>(n)); return;
        }
    };
    size_t end;
    while ((end = buffer.find("\r\n\r\n")) == std::string::npos) {
        if (buffer.size() >= MAX_HEADERS) throw HttpError(431, "headers are too large");
        receive();
    }
    if (end + 4 > MAX_HEADERS) throw HttpError(431, "headers are too large");
    Request req;
    size_t first = buffer.find("\r\n");
    std::istringstream line(buffer.substr(0, first)); std::string version, extra;
    if (!(line >> req.method >> req.target >> version) || (line >> extra) || (version != "HTTP/1.1" && version != "HTTP/1.0") || req.target.empty() || req.target[0] != '/')
        throw HttpError(400, "invalid HTTP request line");
    for (unsigned char c : req.target) if (c < 0x21 || c == 0x7f) throw HttpError(400, "invalid request target");
    size_t pos = first + 2;
    while (pos < end) {
        auto next = buffer.find("\r\n", pos); auto header = buffer.substr(pos, next - pos);
        auto colon = header.find(':');
        if (colon == std::string::npos || !colon) throw HttpError(400, "invalid HTTP header");
        std::string name = lower(header.substr(0, colon));
        if (name.find_first_not_of("abcdefghijklmnopqrstuvwxyz0123456789!#$%&'*+-.^_`|~") != std::string::npos)
            throw HttpError(400, "invalid header name");
        auto value = trim(header.substr(colon + 1));
        for (unsigned char c : value) if ((c < 32 && c != '\t') || c == 127) throw HttpError(400, "invalid header value");
        if (!req.headers.emplace(name, value).second) throw HttpError(400, "duplicate HTTP header");
        pos = next + 2;
    }
    if (req.headers.count("transfer-encoding")) throw HttpError(400, "chunked requests are not supported; use Content-Length");
    if (req.headers.count("expect")) throw HttpError(417, "Expect is not supported");
    uint64_t length = 0;
    auto cl = req.headers.find("content-length");
    if (cl != req.headers.end()) {
        length = decimal(cl->second, UINT64_MAX);
        if (length > MAX_BODY) throw HttpError(413, "request body is too large");
    } else if (req.method == "PUT") throw HttpError(411, "Content-Length is required");
    while (buffer.size() - end - 4 < length) receive();
    req.body = buffer.substr(end + 4, static_cast<size_t>(length));
    return req;
}
const char* reason(int s) {
    switch (s) {
        case 200: return "OK"; case 201: return "Created"; case 400: return "Bad Request";
        case 403: return "Forbidden"; case 404: return "Not Found"; case 405: return "Method Not Allowed";
        case 408: return "Request Timeout"; case 411: return "Length Required"; case 413: return "Content Too Large";
        case 415: return "Unsupported Media Type"; case 417: return "Expectation Failed";
        case 431: return "Request Header Fields Too Large"; case 503: return "Service Unavailable";
        default: return "Internal Server Error";
    }
}
void respond(int fd, const Response& response) {
    std::string message = "HTTP/1.1 " + std::to_string(response.status) + " " + reason(response.status) + "\r\n"
        "Content-Type: " + response.type + "\r\nContent-Length: " + std::to_string(response.body.size()) + "\r\n"
        "Connection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n"
        "X-Frame-Options: DENY\r\nReferrer-Policy: no-referrer\r\n"
        "Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'\r\n\r\n" + response.body;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    size_t sent = 0;
    while (sent < message.size()) {
        auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
        if (remaining <= 0) return;
        pollfd pfd{fd, POLLOUT, 0}; int ready = ::poll(&pfd, 1, static_cast<int>(remaining));
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0) return;
        ssize_t n = ::send(fd, message.data() + sent, message.size() - sent, MSG_DONTWAIT);
        if (n < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        if (n <= 0) return;
        sent += static_cast<size_t>(n);
    }
}
void finish(int fd) {
    // Send FIN after the response, then discard already-buffered request bytes.
    // Closing a socket with unread input can otherwise reset the connection and
    // hide an oversized-request error from the client. Never wait for more input.
    ::shutdown(fd, SHUT_WR);
    char discard[8192]; size_t drained = 0;
    while (drained < MAX_BODY + MAX_HEADERS) {
        ssize_t n = ::recv(fd, discard, sizeof(discard), MSG_DONTWAIT);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        drained += static_cast<size_t>(n);
    }
    ::close(fd);
}
Response error(int status, const std::string& message) { return {status, "{\"error\":" + json::quote(message) + "}"}; }
std::string metadata(const Item& item, bool value) {
    std::string out = "{\"key\":" + json::quote(item.key);
    if (value) out += ",\"value\":" + json::quote(item.value);
    out += ",\"ttl_seconds\":";
    out += item.expires_at_ms ? std::to_string(std::max<int64_t>(0, (item.expires_at_ms - Store::now_ms() + 999) / 1000)) : "null";
    out += ",\"expires_at_ms\":" + (item.expires_at_ms ? std::to_string(item.expires_at_ms) : "null");
    return out + "}";
}
Response route(Store& store, const Request& req, const ServerOptions& options, std::chrono::steady_clock::time_point started) {
    std::string host1 = "127.0.0.1:" + std::to_string(options.port), host2 = "localhost:" + std::to_string(options.port);
    auto host = req.headers.find("host");
    if (host == req.headers.end() || (host->second != host1 && host->second != host2))
        throw HttpError(403, "Host must be localhost or 127.0.0.1 with the server port");
    auto origin = req.headers.find("origin");
    if (origin != req.headers.end() && origin->second != "http://" + host->second)
        throw HttpError(403, "cross-origin requests are not allowed");
    auto site = req.headers.find("sec-fetch-site");
    if (site != req.headers.end() && site->second == "cross-site") throw HttpError(403, "cross-site requests are not allowed");
    auto q = req.target.find('?');
    std::string path = req.target.substr(0, q);
    if (path == "/" && req.method == "GET") return {200, DASHBOARD, "text/html; charset=utf-8"};
    if (path == "/health" && req.method == "GET") {
        auto s = store.stats(); return {s.writable ? 200 : 503, std::string("{\"status\":\"") + (s.writable ? "ok" : "read_only") + "\"}"};
    }
    if (path == "/stats" && req.method == "GET") {
        auto s = store.stats(); auto uptime = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - started).count();
        return {200, "{\"keys\":" + std::to_string(s.keys) + ",\"value_bytes\":" + std::to_string(s.value_bytes) +
            ",\"hits\":" + std::to_string(s.hits) + ",\"misses\":" + std::to_string(s.misses) +
            ",\"writes\":" + std::to_string(s.writes) + ",\"deletes\":" + std::to_string(s.deletes) +
            ",\"expirations\":" + std::to_string(s.expirations) + ",\"log_bytes\":" + std::to_string(s.log_bytes) +
            ",\"uptime_seconds\":" + std::to_string(uptime) + ",\"workers\":" + std::to_string(options.threads) +
            ",\"writable\":" + (s.writable ? "true" : "false") + "}"};
    }
    if (path == "/keys" && req.method == "GET") {
        std::map<std::string, std::string> params;
        if (q != std::string::npos) {
            std::string query = req.target.substr(q + 1); size_t pos = 0;
            while (pos < query.size()) {
                size_t end = query.find('&', pos); if (end == std::string::npos) end = query.size();
                std::string part = query.substr(pos, end - pos); auto eq = part.find('=');
                auto name = decode(part.substr(0, eq), true), value = eq == std::string::npos ? "" : decode(part.substr(eq + 1), true);
                if (name != "prefix" && name != "after" && name != "limit") throw HttpError(400, "unknown query parameter");
                if (!params.emplace(name, value).second) throw HttpError(400, "duplicate query parameter");
                pos = end + 1;
            }
        }
        size_t limit = params.count("limit") ? decimal(params["limit"], 1000) : 100;
        if (!limit) throw HttpError(400, "limit must be between 1 and 1000");
        bool more = false; auto items = store.list(params["prefix"], params["after"], limit, more);
        std::string body = "{\"keys\":[";
        for (size_t i = 0; i < items.size(); ++i) { if (i) body += ','; body += metadata(items[i], false); }
        body += "],\"next_after\":" + (more && !items.empty() ? json::quote(items.back().key) : "null") + "}";
        return {200, body};
    }
    if (path.compare(0, 6, "/keys/") == 0) {
        auto key = decode(path.substr(6));
        if (key.empty() || key.size() > MAX_KEY) throw HttpError(400, "key must be 1–512 UTF-8 bytes");
        if (req.method == "GET") {
            auto item = store.get(key); return item ? Response{200, metadata(*item, true)} : error(404, "key not found");
        }
        if (req.method == "DELETE") return store.remove(key) ? Response{200, "{\"deleted\":true}"} : error(404, "key not found");
        if (req.method == "PUT") {
            auto ct = req.headers.find("content-type");
            if (ct == req.headers.end() || lower(trim(ct->second.substr(0, ct->second.find(';')))) != "application/json")
                throw HttpError(415, "Content-Type must be application/json");
            auto doc = json::parse(req.body);
            if (doc.type != json::Value::Object) throw HttpError(400, "body must be a JSON object");
            for (const auto& field : doc.object) if (field.first != "value" && field.first != "ttl_seconds") throw HttpError(400, "unknown JSON field: " + field.first);
            auto val = doc.object.find("value");
            if (val == doc.object.end() || val->second.type != json::Value::String) throw HttpError(400, "value must be a string");
            if (val->second.text.size() > MAX_VALUE) throw HttpError(413, "value exceeds 65536 UTF-8 bytes");
            int64_t ttl = 0; auto ti = doc.object.find("ttl_seconds");
            if (ti != doc.object.end() && ti->second.type != json::Value::Null) {
                ttl = ti->second.integer(); if (ttl < 1 || ttl > MAX_TTL) throw HttpError(400, "ttl_seconds must be 1–315360000, or null");
            }
            bool created = store.put(key, val->second.text, ttl);
            return {created ? 201 : 200, std::string("{\"key\":") + json::quote(key) + ",\"created\":" + (created ? "true" : "false") + "}"};
        }
        throw HttpError(405, "use GET, PUT, or DELETE for a key");
    }
    if (path == "/" || path == "/health" || path == "/stats" || path == "/keys") throw HttpError(405, "use GET for this endpoint");
    return error(404, "endpoint not found");
}

class Pool {
    Store& store_; ServerOptions options_;
    std::chrono::steady_clock::time_point started_ = std::chrono::steady_clock::now();
    std::mutex mutex_; std::condition_variable ready_;
    std::deque<int> queue_; std::vector<std::thread> workers_; bool stopped_ = false;
    void work() {
        for (;;) {
            int fd;
            {
                std::unique_lock<std::mutex> lock(mutex_); ready_.wait(lock, [this] { return stopped_ || !queue_.empty(); });
                if (queue_.empty()) return;
                fd = queue_.front(); queue_.pop_front();
            }
            try { auto request = read_request(fd); respond(fd, route(store_, request, options_, started_)); }
            catch (const HttpError& e) { respond(fd, error(e.status, e.what())); }
            catch (const json::Error& e) { respond(fd, error(400, e.what())); }
            catch (const std::exception& e) { std::cerr << "Request failed: " << e.what() << '\n'; respond(fd, error(503, "storage or server error; check server log")); }
            finish(fd);
        }
    }
public:
    Pool(Store& store, ServerOptions options) : store_(store), options_(options) {
        try { for (unsigned i = 0; i < options.threads; ++i) workers_.emplace_back([this] { work(); }); }
        catch (...) { shutdown(); throw; }
    }
    ~Pool() { shutdown(); }
    void shutdown() {
        {
            std::lock_guard<std::mutex> lock(mutex_); stopped_ = true;
            for (int fd : queue_) ::close(fd);
            queue_.clear();
        }
        ready_.notify_all(); for (auto& worker : workers_) if (worker.joinable()) worker.join();
    }
    bool enqueue(int fd) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (queue_.size() >= MAX_QUEUE) return false;
        queue_.push_back(fd); ready_.notify_one(); return true;
    }
};
}

void serve(Store& store, const ServerOptions& options) {
    int listener = ::socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) throw std::runtime_error("could not create listening socket");
    try {
        int one = 1; ::setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        ::fcntl(listener, F_SETFD, FD_CLOEXEC);
        ::fcntl(listener, F_SETFL, O_NONBLOCK);
        sockaddr_in address{}; address.sin_family = AF_INET; address.sin_port = htons(static_cast<uint16_t>(options.port));
        address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (::bind(listener, reinterpret_cast<sockaddr*>(&address), sizeof(address)) < 0)
            throw std::runtime_error("could not bind port " + std::to_string(options.port) + ": " + std::strerror(errno));
        if (::listen(listener, 128) < 0) throw std::runtime_error("listen failed");
        Pool pool(store, options);
        std::cout << "Mini Redis is running at http://127.0.0.1:" << options.port << "\n"
                  << "Workers: " << options.threads << " | Durability: fsync on every mutation | Ctrl+C to stop\n" << std::flush;
        while (!stop_requested) {
            pollfd pfd{listener, POLLIN, 0}; int n = ::poll(&pfd, 1, 200);
            if (n < 0 && errno == EINTR) continue;
            if (n < 0) throw std::runtime_error("listener poll failed");
            if (!n) continue;
            int fd = ::accept(listener, nullptr, nullptr);
            if (fd < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
            if (fd < 0) throw std::runtime_error("accept failed");
            ::fcntl(fd, F_SETFD, FD_CLOEXEC);
            if (!pool.enqueue(fd)) { respond(fd, error(503, "server queue is full; retry later")); finish(fd); }
        }
        std::cout << "Stopping server…\n";
    } catch (...) { ::close(listener); throw; }
    ::close(listener);
}
