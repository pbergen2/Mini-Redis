#pragma once
#include "store.hpp"
#include <csignal>
#include <string>

struct ServerOptions { unsigned port = 7379, threads = 4; };
extern volatile std::sig_atomic_t stop_requested;
void serve(Store& store, const ServerOptions& options);
