#pragma once

#include <cstdint>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// Small strict JSON codec. Numbers retain their text so integer validation never
// loses precision through floating point. No external runtime dependencies.
namespace json {
struct Error : std::runtime_error { using std::runtime_error::runtime_error; };

inline bool valid_utf8(std::string_view s) {
    for (size_t i = 0; i < s.size();) {
        uint32_t c = static_cast<unsigned char>(s[i++]);
        if (c < 0x80) continue;
        unsigned n; uint32_t minimum;
        if (c >= 0xc2 && c <= 0xdf) { n = 1; c &= 0x1f; minimum = 0x80; }
        else if (c >= 0xe0 && c <= 0xef) { n = 2; c &= 0x0f; minimum = 0x800; }
        else if (c >= 0xf0 && c <= 0xf4) { n = 3; c &= 7; minimum = 0x10000; }
        else return false;
        if (i + n > s.size()) return false;
        for (unsigned j = 0; j < n; ++j) {
            auto b = static_cast<unsigned char>(s[i++]);
            if ((b & 0xc0) != 0x80) return false;
            c = (c << 6) | (b & 0x3f);
        }
        if (c < minimum || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff)) return false;
    }
    return true;
}

inline std::string quote(std::string_view s) {
    static const char hex[] = "0123456789abcdef";
    std::string out = "\"";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c < 0x20) {
            out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15];
        } else out += static_cast<char>(c);
    }
    return out + '"';
}

struct Value {
    enum Type { Null, Boolean, Number, String, Object, Array } type = Null;
    std::string text;
    std::map<std::string, Value> object;
    std::vector<Value> array;
    int64_t integer() const {
        if (type != Number || text.find_first_of(".eE") != std::string::npos)
            throw Error("expected an integer");
        try { size_t n = 0; auto v = std::stoll(text, &n); if (n == text.size()) return v; }
        catch (const std::exception&) {}
        throw Error("integer is outside the supported range");
    }
};

class Parser {
    std::string_view s; size_t p = 0;
    [[noreturn]] void fail() const { throw Error("invalid JSON at byte " + std::to_string(p)); }
    void ws() { while (p < s.size() && (s[p] == ' ' || s[p] == '\n' || s[p] == '\r' || s[p] == '\t')) ++p; }
    bool take(char c) { if (p < s.size() && s[p] == c) { ++p; return true; } return false; }
    uint32_t hex4() {
        uint32_t n = 0;
        for (int i = 0; i < 4; ++i) {
            if (p == s.size()) fail();
            char c = s[p++]; n <<= 4;
            if (c >= '0' && c <= '9') n |= c - '0';
            else if (c >= 'a' && c <= 'f') n |= c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') n |= c - 'A' + 10;
            else fail();
        }
        return n;
    }
    static void utf8(std::string& out, uint32_t c) {
        if (c < 0x80) out += static_cast<char>(c);
        else if (c < 0x800) {
            out += static_cast<char>(0xc0 | (c >> 6)); out += static_cast<char>(0x80 | (c & 63));
        } else if (c < 0x10000) {
            out += static_cast<char>(0xe0 | (c >> 12)); out += static_cast<char>(0x80 | ((c >> 6) & 63)); out += static_cast<char>(0x80 | (c & 63));
        } else {
            out += static_cast<char>(0xf0 | (c >> 18)); out += static_cast<char>(0x80 | ((c >> 12) & 63)); out += static_cast<char>(0x80 | ((c >> 6) & 63)); out += static_cast<char>(0x80 | (c & 63));
        }
    }
    std::string string() {
        if (!take('"')) fail();
        std::string out;
        while (p < s.size()) {
            unsigned char c = s[p++];
            if (c == '"') return out;
            if (c < 32) fail();
            if (c != '\\') { out += static_cast<char>(c); continue; }
            if (p == s.size()) fail();
            switch (s[p++]) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u': {
                    uint32_t cp = hex4();
                    if (cp >= 0xd800 && cp <= 0xdbff) {
                        if (!take('\\') || !take('u')) fail();
                        uint32_t lo = hex4();
                        if (lo < 0xdc00 || lo > 0xdfff) fail();
                        cp = 0x10000 + ((cp - 0xd800) << 10) + lo - 0xdc00;
                    } else if (cp >= 0xdc00 && cp <= 0xdfff) fail();
                    utf8(out, cp); break;
                }
                default: fail();
            }
        }
        fail();
    }
    Value value(unsigned depth) {
        if (depth > 32) throw Error("JSON nesting exceeds 32 levels");
        ws(); if (p == s.size()) fail();
        Value v;
        if (s[p] == '"') { v.type = Value::String; v.text = string(); }
        else if (take('{')) {
            v.type = Value::Object; ws();
            if (take('}')) return v;
            do {
                ws(); auto k = string(); ws(); if (!take(':')) fail();
                auto child = value(depth + 1);
                if (!v.object.emplace(k, std::move(child)).second) throw Error("duplicate JSON field");
                ws(); if (take('}')) return v;
            } while (take(','));
            fail();
        } else if (take('[')) {
            v.type = Value::Array; ws(); if (take(']')) return v;
            do { v.array.push_back(value(depth + 1)); ws(); if (take(']')) return v; } while (take(','));
            fail();
        } else if (s.substr(p, 4) == "null") { p += 4; }
        else if (s.substr(p, 4) == "true") { p += 4; v.type = Value::Boolean; v.text = "true"; }
        else if (s.substr(p, 5) == "false") { p += 5; v.type = Value::Boolean; v.text = "false"; }
        else {
            v.type = Value::Number; size_t start = p;
            take('-');
            if (!take('0')) {
                if (p == s.size() || s[p] < '1' || s[p] > '9') fail();
                while (p < s.size() && s[p] >= '0' && s[p] <= '9') ++p;
            }
            auto digits = [&] { size_t before = p; while (p < s.size() && s[p] >= '0' && s[p] <= '9') ++p; if (p == before) fail(); };
            if (take('.')) digits();
            if (take('e') || take('E')) { if (!take('+')) take('-'); digits(); }
            v.text = std::string(s.substr(start, p - start));
        }
        return v;
    }
public:
    explicit Parser(std::string_view input) : s(input) {}
    Value parse() {
        if (!valid_utf8(s)) throw Error("JSON must be valid UTF-8");
        auto v = value(0); ws(); if (p != s.size()) fail(); return v;
    }
};
inline Value parse(std::string_view s) { return Parser(s).parse(); }
} // namespace json
