#pragma once
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

constexpr size_t MAX_KEY = 512;
constexpr size_t MAX_VALUE = 65536;
constexpr int64_t MAX_TTL = 315360000; // Ten years, in seconds.

struct Item { std::string key, value; int64_t expires_at_ms = 0; };
struct Stats {
    size_t keys = 0, value_bytes = 0;
    uint64_t hits = 0, misses = 0, writes = 0, deletes = 0, expirations = 0;
    int64_t log_bytes = 0;
    bool writable = true;
};

class Store {
    using Expiries = std::multimap<int64_t, std::string>;
    struct Entry {
        std::string value;
        int64_t expires_at_ms;
        std::optional<Expiries::iterator> expiry;
    };
    std::mutex mutex_;
    std::unordered_map<std::string, Entry> data_;
    Expiries expiries_;
    Stats stats_;
    int fd_ = -1;
    bool writable_ = true;
    std::thread reaper_;
    std::condition_variable wake_;
    bool stopping_ = false;
    void erase_memory(const std::string& key);
    void set_memory(const Item& item);
    void expire_locked(int64_t now);
    void append(char op, const Item& item);
    void recover();
public:
    explicit Store(const std::string& directory);
    ~Store();
    Store(const Store&) = delete;
    Store& operator=(const Store&) = delete;
    static int64_t now_ms();
    std::optional<Item> get(const std::string& key);
    bool put(const std::string& key, const std::string& value, int64_t ttl_seconds);
    bool remove(const std::string& key);
    std::vector<Item> list(const std::string& prefix, const std::string& after, size_t limit, bool& more);
    Stats stats();
};
