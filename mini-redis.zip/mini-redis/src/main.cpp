#include "http.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void stop(int) { stop_requested = 1; }
unsigned number(const std::string& s, unsigned low, unsigned high) {
    if (s.empty() || s.find_first_not_of("0123456789") != std::string::npos) throw std::runtime_error("expected a positive integer");
    auto n = std::stoul(s); if (n < low || n > high) throw std::runtime_error("number outside allowed range");
    return static_cast<unsigned>(n);
}
}
int main(int argc, char** argv) {
    try {
        ServerOptions options; std::string directory = "data";
        for (int i = 1; i < argc; ++i) {
            std::string arg = argv[i];
            if (arg == "--help" || arg == "-h") {
                std::cout << "Mini Redis — C++17 key-value server\n\n"
                          << "Usage: mini-redis [--port 7379] [--threads 4] [--data-dir data]\n\n"
                          << "Listens on 127.0.0.1 only. Open http://127.0.0.1:7379 for the dashboard.\n"
                          << "Writes use an append-only log with fsync before acknowledgement.\n"
                          << "Press Ctrl+C to stop.\n"; return 0;
            }
            if (i + 1 == argc) throw std::runtime_error("missing value for " + arg);
            std::string value = argv[++i];
            if (arg == "--port") options.port = number(value, 1, 65535);
            else if (arg == "--threads") options.threads = number(value, 1, 64);
            else if (arg == "--data-dir") { if (value.empty()) throw std::runtime_error("data directory cannot be empty"); directory = value; }
            else throw std::runtime_error("unknown option: " + arg);
        }
        std::signal(SIGINT, stop); std::signal(SIGTERM, stop); std::signal(SIGPIPE, SIG_IGN);
        Store store(directory);
        serve(store, options);
    } catch (const std::exception& e) { std::cerr << "Error: " << e.what() << '\n'; return 1; }
}
