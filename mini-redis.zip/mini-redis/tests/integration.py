#!/usr/bin/env python3
"""Black-box API, concurrency, protocol, and disk-recovery tests. Standard library only."""
import argparse
import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import signal
import socket
import struct
import subprocess
import tempfile
import time
import unittest
from urllib.parse import quote

PARSER = argparse.ArgumentParser()
PARSER.add_argument('--binary', required=True)
ARGS, REMAINING = PARSER.parse_known_args()
BINARY = str(Path(ARGS.binary).resolve())


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


class Server:
    def __init__(self, directory):
        self.directory = directory
        self.port = free_port()
        self.proc = None
        self.output = ''

    def start(self):
        self.proc = subprocess.Popen([BINARY, '--port', str(self.port), '--data-dir', self.directory, '--threads', '4'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for _ in range(150):
            if self.proc.poll() is not None:
                self.output = self.proc.communicate()[0]
                raise RuntimeError(self.output)
            try:
                if self.request('GET', '/health')[0] == 200:
                    return self
            except (OSError, http.client.HTTPException):
                pass
            time.sleep(.02)
        self.stop()
        raise RuntimeError('server did not become ready: ' + self.output)

    def stop(self, crash=False):
        if self.proc:
            if self.proc.poll() is None:
                self.proc.send_signal(signal.SIGKILL if crash else signal.SIGTERM)
            out, _ = self.proc.communicate(timeout=12)
            self.output += out
            if not crash and self.proc.returncode != 0:
                raise AssertionError('Server exited unsuccessfully: ' + self.output)
            self.proc = None

    def request(self, method, path, payload=None, headers=None, raw=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=8)
        body = raw if raw is not None else json.dumps(payload) if payload is not None else None
        hdr = {'Content-Type': 'application/json'}
        if headers:
            hdr.update(headers)
        try:
            conn.request(method, path, body=body, headers=hdr)
            response = conn.getresponse()
            data = response.read().decode()
            if response.getheader('Content-Type', '').startswith('application/json'):
                data = json.loads(data)
            return response.status, data
        finally:
            conn.close()

    def wire(self, raw):
        with socket.create_connection(('127.0.0.1', self.port), timeout=8) as sock:
            sock.sendall(raw)
            sock.shutdown(socket.SHUT_WR)
            data = b''
            while True:
                part = sock.recv(65536)
                if not part:
                    break
                data += part
        return int(data.split(b' ')[1]), data


class Integration(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='mini-redis-test-')
        self.server = Server(self.tmp.name).start()

    def tearDown(self):
        try:
            self.server.stop()
        finally:
            self.tmp.cleanup()

    def put(self, key, value, **extra):
        return self.server.request('PUT', '/keys/' + quote(key, safe=''), {'value': value, **extra})

    def get(self, key):
        return self.server.request('GET', '/keys/' + quote(key, safe=''))

    def test_crud_and_counters(self):
        self.assertEqual(self.put('workout:last', 'Pull day')[0], 201)
        self.assertEqual(self.put('workout:last', 'Push day')[0], 200)
        status, body = self.get('workout:last')
        self.assertEqual(status, 200)
        self.assertEqual(body['value'], 'Push day')
        self.assertIsNone(body['ttl_seconds'])
        self.assertEqual(self.get('missing')[0], 404)
        stats = self.server.request('GET', '/stats')[1]
        self.assertEqual((stats['keys'], stats['writes'], stats['hits'], stats['misses']), (1, 2, 1, 1))
        self.assertEqual(stats['value_bytes'], 8)
        self.assertEqual(self.server.request('DELETE', '/keys/workout:last')[0], 200)
        self.assertEqual(self.server.request('DELETE', '/keys/workout:last')[0], 404)

    def test_unicode_escapes_empty_and_maximum_values(self):
        key = '🧗/café? #+%\x00'
        value = 'line\nquote" backslash\\ tab\t nul\x00 🧗'
        self.assertEqual(self.put(key, value)[0], 201)
        self.assertEqual(self.get(key)[1]['value'], value)
        self.assertEqual(self.put('empty', '')[0], 201)
        self.assertEqual(self.get('empty')[1]['value'], '')
        self.assertEqual(self.put('maximum', '\x00' * 65536)[0], 201)
        self.assertEqual(len(self.get('maximum')[1]['value']), 65536)
        self.assertEqual(self.put('x' * 512, 'ok')[0], 201)
        self.assertEqual(self.put('x' * 513, 'no')[0], 400)
        self.assertEqual(self.put('oversize', 'x' * 65537)[0], 413)

    def test_ttl_expiry_and_overwrite_clears_ttl(self):
        self.put('short', 'temporary', ttl_seconds=1)
        self.put('persistent', 'old', ttl_seconds=1)
        self.put('persistent', 'new')
        self.assertEqual(self.get('short')[1]['ttl_seconds'], 1)
        time.sleep(1.15)
        stats = self.server.request('GET', '/stats')[1]
        self.assertEqual(stats['keys'], 1)
        self.assertEqual(stats['expirations'], 1)
        self.assertEqual(self.get('short')[0], 404)
        self.assertIsNone(self.get('persistent')[1]['ttl_seconds'])

    def test_ttl_replacement_does_not_expire_new_value(self):
        self.put('replace', 'old', ttl_seconds=1)
        self.put('replace', 'new', ttl_seconds=5)
        time.sleep(1.1)
        self.assertEqual(self.get('replace')[1]['value'], 'new')

    def test_recovery_after_sigkill_and_offline_expiration(self):
        self.put('durable', 'first')
        self.put('durable', 'second')
        self.put('deleted', 'gone')
        self.server.request('DELETE', '/keys/deleted')
        self.put('expires-offline', 'gone', ttl_seconds=1)
        self.put('long-ttl', 'stays', ttl_seconds=30)
        deadline = self.get('long-ttl')[1]['expires_at_ms']
        self.server.stop(crash=True)
        time.sleep(1.1)
        self.server.start()
        self.assertEqual(self.get('durable')[1]['value'], 'second')
        self.assertEqual(self.get('deleted')[0], 404)
        self.assertEqual(self.get('expires-offline')[0], 404)
        self.assertEqual(self.get('long-ttl')[1]['expires_at_ms'], deadline)

    def test_incomplete_final_log_record_is_discarded(self):
        self.put('kept', 'yes')
        self.server.stop()
        log = Path(self.tmp.name) / 'appendonly.aof'
        good_size = log.stat().st_size
        for tail in (b'\x20\x00', struct.pack('<II', 40, 123) + b'partial'):
            with log.open('ab') as stream:
                stream.write(tail)
            self.server.start()
            self.assertEqual(self.get('kept')[1]['value'], 'yes')
            self.assertEqual(log.stat().st_size, good_size)
            self.server.stop()
        self.server.start()
        self.assertEqual(self.put('after-repair', 'yes')[0], 201)

    def test_corrupt_complete_record_is_rejected(self):
        self.put('kept', 'original')
        self.server.stop()
        log = Path(self.tmp.name) / 'appendonly.aof'
        data = bytearray(log.read_bytes())
        data[-1] ^= 1
        log.write_bytes(data)
        process = subprocess.run([BINARY, '--port', str(self.server.port), '--data-dir', self.tmp.name], capture_output=True, text=True, timeout=5)
        self.assertNotEqual(process.returncode, 0)
        self.assertIn('checksum mismatch', process.stderr)
        self.assertEqual(log.read_bytes(), data)

    def test_data_directory_lock(self):
        process = subprocess.run([BINARY, '--port', str(free_port()), '--data-dir', self.tmp.name], capture_output=True, text=True, timeout=5)
        self.assertNotEqual(process.returncode, 0)
        self.assertIn('already in use', process.stderr)
        self.assertEqual(self.server.request('GET', '/health')[0], 200)

    def test_concurrent_clients_and_replay(self):
        def job(i):
            key = 'parallel:' + str(i)
            self.assertEqual(self.put(key, str(i))[0], 201)
            self.assertEqual(self.get(key)[1]['value'], str(i))
            self.assertIn(self.put('shared', str(i))[0], (200, 201))
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            list(pool.map(job, range(60)))
        final = self.get('shared')[1]['value']
        self.server.stop(crash=True)
        self.server.start()
        self.assertEqual(self.server.request('GET', '/stats')[1]['keys'], 61)
        self.assertEqual(self.get('shared')[1]['value'], final)
        for i in range(60):
            self.assertEqual(self.get('parallel:' + str(i))[1]['value'], str(i))

    def test_sorted_prefix_pagination(self):
        for key in ['gym:c', 'other', 'gym:a', 'gym:b']:
            self.put(key, 'x')
        status, first = self.server.request('GET', '/keys?prefix=gym%3A&limit=2')
        self.assertEqual(status, 200)
        self.assertEqual([i['key'] for i in first['keys']], ['gym:a', 'gym:b'])
        self.assertEqual(first['next_after'], 'gym:b')
        second = self.server.request('GET', '/keys?prefix=gym%3A&limit=2&after=gym%3Ab')[1]
        self.assertEqual([i['key'] for i in second['keys']], ['gym:c'])
        self.assertIsNone(second['next_after'])

    def test_invalid_json_and_parameters(self):
        for raw in ['{}', '[]', '{"value":3}', '{"value":"x","ttl_seconds":0}', '{"value":"x","ttl_seconds":-1}', '{"value":"x","ttl_seconds":1.5}', '{"value":"x","ttl_seconds":true}', '{"value":"x","ttl_seconds":9223372036854775808}', '{"value":"x","other":1}', '{"value":"x","value":"y"}', '{"value":"\\ud800"}', '{"value":"x",}', '{"value":"x"}junk', '{"value":"x","ttl_seconds":01}', '{"value":"x","ttl_seconds":1e1}']:
            with self.subTest(raw=raw):
                self.assertEqual(self.server.request('PUT', '/keys/bad', raw=raw)[0], 400)
        self.assertEqual(self.put('null-ttl', 'fine', ttl_seconds=None)[0], 201)
        for path in ['/keys?limit=0', '/keys?limit=1001', '/keys?limit=-1', '/keys?foo=x', '/keys?prefix=x&prefix=y', '/keys/%zz', '/keys/%ff', '/keys/']:
            with self.subTest(path=path):
                self.assertEqual(self.server.request('GET', path)[0], 400)
        self.assertEqual(self.server.request('PUT', '/keys/a', raw='{"value":"x"}', headers={'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.server.request('POST', '/keys/a', {})[0], 405)
        self.assertEqual(self.server.request('GET', '/no-such-endpoint')[0], 404)

    def test_http_framing_and_local_origin(self):
        host = f'Host: 127.0.0.1:{self.server.port}\r\n'.encode()
        for headers, expected in [
            (b'Content-Length: 1\r\nContent-Length: 1\r\n', 400),
            (b'Transfer-Encoding: chunked\r\n', 400),
            (b'Content-Length: 524289\r\n', 413),
            (b'Content-Length: 0\r\nExpect: 100-continue\r\n', 417),
            (b'', 411),
            (b'Content-Length: 5\r\n', 400),
            (b'Content-Length: 0\r\nBad Header: x\r\n', 400),
        ]:
            with self.subTest(headers=headers):
                self.assertEqual(self.server.wire(b'PUT /keys/a HTTP/1.1\r\n' + host + headers + b'\r\n')[0], expected)
        self.assertEqual(self.server.request('GET', '/health', headers={'Host': 'evil.example'})[0], 403)
        self.assertEqual(self.server.request('GET', '/health', headers={'Origin': 'https://evil.example'})[0], 403)
        self.assertEqual(self.server.request('GET', '/health', headers={'Origin': f'http://127.0.0.1:{self.server.port}'})[0], 200)
        self.assertEqual(self.server.wire(b'GET /health HTTP/1.1\r\n' + host + b'X-Big: ' + b'x' * 17000 + b'\r\n\r\n')[0], 431)

    def test_dashboard_and_shutdown(self):
        status, html = self.server.request('GET', '/')
        self.assertEqual(status, 200)
        self.assertIn('Key explorer', html)
        self.assertIn('encodeURIComponent', html)
        self.put('shutdown', 'survives')
        self.server.stop()
        self.server.start()
        self.assertEqual(self.get('shutdown')[1]['value'], 'survives')


if __name__ == '__main__':
    unittest.main(argv=[__file__, *REMAINING], verbosity=2)
